#include <iostream>
#include <fstream>
#include <vector>
#include "Student.h"

using namespace std;

int main() {

    vector<Student> studentVector;

    Student newStudent;

    newStudent.getName();

    newStudent.setInitial();

    return 0;
}